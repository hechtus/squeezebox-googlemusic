package Plugins::GoogleMusic::Playlists;

use strict;
use warnings;

use Scalar::Util qw(blessed);
use Slim::Control::Request;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Strings qw(string);

use Plugins::GoogleMusic::GoogleAPI;

my $log = logger('plugin.googlemusic');
my $prefs = preferences('plugin.googlemusic');

my $googleapi = getAPI();
my $playlists;

sub loadPlaylists {

	$playlists = [];
	if (!$googleapi->is_authenticated()) {
		return;
	}

	for my $playlist (@$googleapi->get_all_playlist_contents()) {
		
	}

}

sub _show_playlist {
	my ($client, $playlist) = @_;

	my $menu;

	$menu = {
		name => $playlist->{'name'},
		type => 'playlist',
		url => \&_tracks,
		passthrough => [$playlist->{tracks}, { showArtist => 1, showAlbum => 1, playall => 1 }],
	};

	return $menu;
}

sub _playlists {
	my ($client, $callback, $args) = @_;

	my @menu;

	for my $playlist (@{$playlists}) {
		push @menu, _show_playlist($client, $playlist);
	}

	if (!scalar @menu) {
		push @menu, {
			'name' => string('EMPTY'),
			'type' => 'text',
		}

	}

	$callback->(\@menu);

	return;
}


1;
