
		my $googletrack = $googleapi->get_track($url);
		my $track = Slim::Schema->updateOrCreate({
			'url'      => $url,
			'attributes' => {
				CONTENT_TYPE => 'mp3',
				BITRATE => 320000,
				SECS => $googletrack->{'durationMillis'} / 1000,
				
				ARTISTNAME => $googletrack->{'artist'},
				ALBUMNAME => $googletrack->{'album'},
				COVERURL => Plugins::GoogleMusic::Image->uri($googletrack->{'albumArtUrl'}),
				
				TITLE => $googletrack->{'title'},
				ALBUM => $googletrack->{'album'},
				FILESIZE => $googletrack->{'estimatedSize'},
				# YEAR => $googletrack->{'year'},
				TRACKNUM => $googletrack->{'trackNumber'},
				DISC => $googletrack->{'discNumber'},
				DISCC => $googletrack->{'totalDiscCount'},
				AUDIO => 1,
			},
		});
